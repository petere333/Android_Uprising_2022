#pragma once

#include <cstdio>
#include <cstdlib>
#include <vector>

typedef struct float3
{
	float x, y, z;
}float3;
